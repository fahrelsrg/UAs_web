<?php
//session_start();
if (!empty($_SESSION['username_decafe'])) {
    header('location:home');
}

?>
<!doctype html>
<html lang="en">

<head>
    

    <meta charset="utf-8">
    <meta name="viewport" content="width=device-width, initial-scale=1">
    <meta name="description" content="">
    <meta name="author" content="Mark Otto, Jacob Thornton, and Bootstrap contributors">
    <meta name="generator" content="Hugo 0.122.0">
    <title>Bebas Ekspresi </title>

    <link rel="canonical" href="https://getbootstrap.com/docs/5.3/examples/sign-in/">
    <link rel="stylesheet" href="https://cdn.jsdelivr.net/npm/@docsearch/css@3">
    <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.3.3/dist/css/bootstrap.min.css" rel="stylesheet"
        integrity="sha384-QWTKZyjpPEjISv5WaRU9OFeRpok6YctnYmDr5pNlyT2bRjXh0JMhjY6hW+ALEwIH" crossorigin="anonymous">
    <link rel="stylesheet" href="https://cdn.jsdelivr.net/npm/bootstrap-icons@1.11.3/font/bootstrap-icons.min.css">

    <!-- Custom styles for this template -->
    <link href="assets/css/login.css" rel="stylesheet">
</head>

<body class="d-flex align-items-center py-4 bg-body-tertiary">
    <main class="form-signin w-100 m-auto d-flex flex-column align-items-center justify-content-center" style="min-height: 100%;">
    <img class="logo" src="assets/img/logo.jpg" alt="Logo" width="72" height="72">
        <form class="needs-validation" style="width: 100%; max-width: 330px;" novalidate action="proses/proses_login.php" method="post">

            <h1 class="h3 mb-3 fw-normal text-center">Please Login</h1>

            <div class="form-floating">
                <input name="username" type="email" class="form-control" id="floatingInput" placeholder="name@example.com" required>
                <label for="floatingInput">Email address</label>
                <div class="valid-feedback">
                    Masukan email yang valid
                </div>
                <div class="form-floating">
                    <input name="password" type="password" class="form-control" id="floatingPassword" placeholder="Password" required>
                    <label for="floatingPassword">Password</label>
                    <div class="invalid-feedback">
                        Masukan password.
                    </div>
                </div>

                <div class="checkbox mb-3">
                    <label>
                        <input class="form-check-input" type="checkbox" value="remember-me">Remember me
                    </label>
                </div>
                <button class="w-100 btn btn-lg btn-primmary" type="submit" name="submit_validate" value="abc">LOGIN</button>
                <p class="mt-5 mb-3 text-muted text-center">&copy; JAKARTA 2020 -<?php echo date("Y") ?></p>
            </div>
        </form>
    </main>

    <script>
        // Example starter JavaScript for disabling form submissions if there are invalid fields
        (() => {
            'use strict'

            // Fetch all the forms we want to apply custom Bootstrap validation styles to
            const forms = document.querySelectorAll('.needs-validation')

            // Loop over them and prevent submission
            Array.from(forms).forEach(form => {
                form.addEventListener('submit', event => {
                    if (!form.checkValidity()) {
                        event.preventDefault()
                        event.stopPropagation()
                    }

                    form.classList.add('was-validated')
                }, false)
            })
        })()
    </script>

</body>

</html>

