<div class="col-lg-9  mt-2">
        <div class="card">
          <div class="card-header">
            Product
          </div>
          <div class="card-body">
            <h5 class="card-title">ini adalah bagian product</h5>
            <p class="card-text">With supporting text below as a natural lead-in to additional content.hufgufguugewukgfkuagyfyafgadgfafayjfadjgyjfsbdvhdsvhmds hcjvdshcvdshvhdsvcdshvc</p>
            <a href="#" class="btn btn-primary">Go somewhere</a>
          </div>
        </div>
      </div>