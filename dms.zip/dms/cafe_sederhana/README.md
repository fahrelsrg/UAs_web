# ☕ DeCafe - Aplikasi Pemesanan Cafe & Restoran

<p align="center">
  <img src="assets/img/back.jpg" alt="DeCafe Screenshot" width="400"/>
</p>

<p align="center">
  <a href="#fitur-utama"><img src="https://img.shields.io/badge/Fitur-Utama-blue?style=flat-square"/></a>
  <a href="#cara-instalasi"><img src="https://img.shields.io/badge/Instalasi-Easy-brightgreen?style=flat-square"/></a>
  <a href="#teknologi"><img src="https://img.shields.io/badge/Build-PHP%207%2B%20%7C%20MySQL%20%7C%20Bootstrap%205-orange?style=flat-square"/></a>
</p>

---

Aplikasi web modern untuk memudahkan pemesanan makanan & minuman di cafe, restoran, atau rumah makan. Mendukung multi-role (Admin, Kasir, Pelayan, Dapur) dan terintegrasi dengan sistem laporan serta manajemen menu.

---

## ✨ Fitur Utama
- Manajemen menu makanan & minuman
- Sistem pemesanan multi-user (Admin, Kasir, Pelayan, Dapur)
- Konfirmasi & update status pesanan
- Laporan penjualan
- Otomatisasi kode order & bukti pembayaran
- Responsive, berbasis Bootstrap

## 👥 Peran & Hak Akses

| Peran         | Fitur Utama                                                                 |
|--------------|-----------------------------------------------------------------------------|
| **Admin**    | Kelola menu, harga, kategori, user, laporan penjualan                       |
| **Kasir**    | Lihat & proses pesanan, konfirmasi pembayaran, cetak bukti pembayaran       |
| **Pelayan**  | Lihat menu & harga, buat/update/hapus pesanan                               |
| **Dapur**    | Terima & proses pesanan, update status pesanan (siap saji)                  |

---

## 🚀 Cara Instalasi

1. **Clone repository**
   ```bash
   git clone https://github.com/steven7281/cafe_sederhana.git
   ```
2. **Import database**
   - Buat database `db_decafe` di MySQL
   - Import file SQL (jika tersedia)
3. **Konfigurasi koneksi**
   - Edit `proses/connect.php` jika perlu menyesuaikan user/password database
4. **Jalankan di Localhost**
   - Pastikan folder ada di dalam web server (XAMPP/Laragon/WAMP)
   - Akses via browser: `http://localhost/nama-folder`

---

## 🛠️ Teknologi

![PHP](https://img.shields.io/badge/PHP-7%2B-blue?logo=php&logoColor=white)
![MySQL](https://img.shields.io/badge/MySQL-5.7%2B-blue?logo=mysql&logoColor=white)
![Bootstrap](https://img.shields.io/badge/Bootstrap-5-blueviolet?logo=bootstrap&logoColor=white)
![JavaScript](https://img.shields.io/badge/JavaScript-ES6-yellow?logo=javascript&logoColor=black)

---


## 📄 Lisensi
Aplikasi ini dikembangkan untuk kebutuhan internal cafe/restoran. Silakan modifikasi sesuai kebutuhan.

