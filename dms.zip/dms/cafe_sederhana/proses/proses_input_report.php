<?php
include "connect.php";

$id = isset($_POST['id']) ? htmlentities($_POST['id']) : "";
$nama = isset($_POST['nama']) ? htmlentities($_POST['nama']) : "";
$report = isset($_POST['report']) ? htmlentities($_POST['report']) : "";
$kode_order = isset($_POST['kode_order']) ? htmlentities($_POST['kode_order']) : "";

$kode_rand = rand(10000, 99999) . "-";
$target_dir = "../assets/img/" . $kode_rand;
$target_file = $target_dir . basename($_FILES['foto']['name']);
$imageType = strtolower(pathinfo($target_file, PATHINFO_EXTENSION));

if (!empty($_POST['input_user_validate'])) {
  // Cek apakah file adalah gambar
  $cek = getimagesize($_FILES['foto']['tmp_name']);
  if ($cek === false) {
    $message = "Ini bukan file gambar";
    $statusUpload = 0;
  } else {
    $statusUpload = 1;
    if (file_exists($target_file)) {
      $message = "Maaf, File yang Dimasukkan Telah Ada";
      $statusUpload = 0;
    } else {
      if ($_FILES['foto']['size'] > 500000) { // 500kb
        $message = "File foto yang di upload terlalu besar";
        $statusUpload = 0;
      } else {
        if (!in_array($imageType, ['jpg', 'jpeg', 'png', 'gif'])) {
          $message = "Maaf, hanya diperbolehkan gambar yang memiliki format JPG, JPEG, PNG dan GIF";
          $statusUpload = 0;
        }
      }
    }
  }

  if ($statusUpload == 0) {
    echo '<script>alert("' . $message . ', Gambar tidak dapat diupload");
          window.location="../report";</script>';
  } else {
    // Cek apakah data dengan ID yang sama sudah ada
    $select = mysqli_query($conn, "SELECT * FROM tb_report WHERE nama = '$nama'");
    if (mysqli_num_rows($select) > 0) {
      echo '<script>alert("nama menu yang dimasukkan telah ada");
            window.location="../report";</script>';
    } else {
      if (move_uploaded_file($_FILES['foto']['tmp_name'], $target_file)) {
        // Memasukkan data ke dalam database
        $foto = $kode_rand . $_FILES['foto']['name'];
        $query = mysqli_query($conn, "INSERT INTO tb_report (foto, nama, report, kode_order) VALUES ('$foto', '$nama', '$report', '$kode_order')");

        if ($query) {
          echo '<script>alert("Data berhasil dimasukkan");
                window.location="../report";</script>';
        } else {
          echo '<script>alert("Data gagal dimasukkan: ' . mysqli_error($conn) . '");
                window.location="../report";</script>';
        }
      } else {
        echo '<script>alert("Maaf, terjadi kesalahan file tidak dapat diupload");
              window.location="../report";</script>';
      }
    }
  }
}
?>
