<?php
include "connect.php";
$jenismenu = isset($_POST['jenismenu']) ? htmlentities($_POST['jenismenu']) : "";
$katmenu = isset($_POST['katmenu']) ? htmlentities($_POST['katmenu']) : "";

if (!empty($_POST['input_katmenu_validate'])) {
    $select = mysqli_query($conn, "SELECT kategori_menu FROM tb_kategori_menu WHERE kategori_menu = '$katmenu'");
    if (mysqli_num_rows($select) > 0) {
        $message = '<script>alert("kategori yang di masukan telah ada"); window.location="../katmenu"</script>';
    } else {
        // Menghapus tanda koma yang tidak perlu dan menggunakan variabel $katmenu
        $query = mysqli_query($conn, "INSERT INTO tb_kategori_menu (jenis_menu, kategori_menu) VALUES ('$jenismenu', '$katmenu')");
        if ($query) {
            $message = '<script>alert("Data berhasil dimasukkan"); window.location="../katmenu"</script>';
        } else {
            $message = '<script>alert("Data gagal dimasukkan"); window.location="../katmenu"</script>';
        }
    }
}

echo $message;
?>
<script>
    // Example starter JavaScript for disabling form submissions if there are invalid fields
    (() => {
      'use strict'

      // Fetch all the forms we want to apply custom Bootstrap validation styles to
      const forms = document.querySelectorAll('.needs-validation')

      // Loop over them and prevent submission
      Array.from(forms).forEach(form => {
        form.addEventListener('submit', event => {
          if (!form.checkValidity()) {
            event.preventDefault()
            event.stopPropagation()
          }

          form.classList.add('was-validated')
        }, false)
      })
    })()
  </script>