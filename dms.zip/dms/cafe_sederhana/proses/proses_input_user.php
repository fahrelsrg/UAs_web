<?php
include "connect.php";


$name = isset($_POST['nama']) ? htmlentities( $_POST['nama']) : "";
$username = isset($_POST['username']) ? htmlentities( $_POST['username']) : "";
$level = isset($_POST['level']) ? htmlentities( $_POST['level']) : "";
$nohp = isset($_POST['nohp']) ? htmlentities( $_POST['nohp']) : "";
$alamat = isset($_POST['alamat']) ? htmlentities( $_POST['alamat']) : "";
$password = md5('password');


if (!empty($_POST['input_user_validate'])) {
    $select = mysqli_query($conn, "SELECT * FROM tb_user WHERE username = '$username'");
    if (mysqli_num_rows($select) > 0) {
        $message = '<script>alert("username yang di masukan telah ada"); window.location="../user"</script>';
    } else {
        $query = mysqli_query($conn, "INSERT INTO tb_user (nama, username, level, nohp, alamat, password) 
                                   VALUES ('$name', '$username', '$level', '$nohp', '$alamat', '$password')");
        if ($query) {
            $message = '<script>alert("Data berhasil dimasukkan"); window.location="../user"</script>';
        } else {
            $message = '<script>alert("Data gagal dimasukkan")</script>';
        }
    }
}

echo $message;
?>
<script>
    // Example starter JavaScript for disabling form submissions if there are invalid fields
    (() => {
      'use strict'

      // Fetch all the forms we want to apply custom Bootstrap validation styles to
      const forms = document.querySelectorAll('.needs-validation')

      // Loop over them and prevent submission
      Array.from(forms).forEach(form => {
        form.addEventListener('submit', event => {
          if (!form.checkValidity()) {
            event.preventDefault()
            event.stopPropagation()
          }

          form.classList.add('was-validated')
        }, false)
      })
    })()
  </script>